//
//  ViewController.swift
//  UserDefaultsApp
//
//  Created by MacStudent on 2018-07-09.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // play with userdefault here
        
        //1. tell ios you want to use userdefaluts(localstorage from web)
        let defaults = UserDefaults.standard
       
        
        //2. add some things to the userdfault
        defaults.set("Navu", forKey: "studentName")
        
        //boolean
        defaults.set(true,forKey:"isInstructor")
        
        //double
        defaults.set(800.59,forKey: "hourlyRate")
        
        //array
        let courseTaught = ["ios 101", "android 101", "swift 101", "java 101","database"]
        defaults.set(courseTaught,forKey:"courses")
        
        //dictionary
        let student = ["name":"Prabh","id":"c0728699","program":"MADT","sem":"second"]
        defaults.set(student,forKey:"student")
        
        
        
        //3. print /get stuff from userdefault
         //print(defaults.dictionaryRepresentation())
        
        //get a specific thing from the dictionary
        let x = defaults.double(forKey: "hourlyRate")
        print(x)
        
        print("Is navu an instructor?")
        print(defaults.bool(forKey: "isInstructor"))
        //get a string
        print("What is her full name?")
        let name = defaults.string(forKey: "studentName")
        print(name!)
        //get a array
        print("what courses she has learned??")
        let c = defaults.array(forKey: "courses") as![String]
        print(c)
        
        //get a dictionary
        print("who is the student?")
        let d = defaults.dictionary(forKey: "student") as!Dictionary<String,String>
        print(d)
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

