//
//  ViewController.swift
//  coreData01
//
//  Created by MacStudent on 2018-07-10.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        //1. create variable that allows you to interact with
        //coredata database
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        let managedContext = appDelegate.persistentContainer.viewContext
        
        
        
        //2. create a row in the table
        //2a. what table do i want to intract with?(user)
        let userEntity = NSEntityDescription.entity(forEntityName: "User", in: managedContext)
        
        //2b. make the row in the table
        //-----create a new user object
        let user = NSManagedObject(entity: userEntity!, insertInto: managedContext)
        
        //----set the properties of the object
        user.setValue("Jigesha Patel", forKey: "name")
        user.setValue("jigesha@gmail.com", forKey: "email")
        user.setValue(5, forKey: "kids")
        
        //make a date
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-mm-dd"
        let date = formatter.date(from:"1990-05-11")
        user.setValue(date, forKey: "birthday")
        
        print(user)
        //3. save the row to the table
        do{
            try managedContext.save()
        }
        catch{
            print("Problem saving to database")
        }
        print("done saving to database")
        //4. show
        //4a. create a SELECT * from user
        let userFetch = NSFetchRequest<NSFetchRequestResult>(entityName: "User")
        
        //4b. run the sql
        do{
           let users = try managedContext.fetch(userFetch)
            print(users)
            
        }
        catch{
            print("ERROR WHILE FETCHING STUFF FROM DATABASE")
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

