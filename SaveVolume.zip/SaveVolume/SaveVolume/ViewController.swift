//
//  ViewController.swift
//  SaveVolume
//
//  Created by robin on 2017-11-08.
//  Copyright © 2017 robin. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    //variables
    
    @IBOutlet weak var slidervalue: UISlider!
    @IBOutlet weak var textvalue: UITextField!
     let defaults = UserDefaults.standard
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
       
        let x = defaults.float(forKey: "volume")
        textvalue.text="\(x)"
        slidervalue.value = x
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func slider(_ sender: UISlider) {
        
            let volu = sender.value
            //print(volume)
        
            textvalue.text="\(volu)"
        defaults.set(volu,forKey:"volume")
        
            let x = defaults.float(forKey: "volume")
            textvalue.text="\(x)"
          
    }
}


